import 'package:flutter/material.dart';

class CurrencyConverterText extends StatelessWidget {
  const CurrencyConverterText({super.key});

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(8.0),
      child: Text(
        'Currency Converter',
        style: TextStyle(color: Color.fromARGB(255, 255, 255, 255)),
      ),
    );
  }
}
