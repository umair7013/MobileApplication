import 'package:flutter/material.dart';

class CurrencyTextButton extends StatelessWidget {
  const CurrencyTextButton({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextButton(
        onPressed: () {
          debugPrint("Pressed");
        },
        style: const ButtonStyle(
          backgroundColor: WidgetStatePropertyAll<Color>(
            Color.fromARGB(222, 241, 38, 109),
          ),
          foregroundColor: WidgetStatePropertyAll<Color>(
            Color.fromARGB(222, 62, 225, 204),
          ),
          fixedSize: WidgetStatePropertyAll<Size>(
            Size(200, 50),
          ),
        ),
        child: const Text(
          'Convertor Button',
          style: TextStyle(color: Color.fromARGB(122, 228, 231, 238)),
        ),
      ),
    );
  }
}
