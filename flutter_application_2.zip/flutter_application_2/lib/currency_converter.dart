import 'package:flutter/material.dart';

class CurrencyConverter extends StatelessWidget {
  const CurrencyConverter({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
            backgroundColor: const Color.fromARGB(255, 9, 245, 186),
            body: Center(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('Ali Umair',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold)),
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: TextField(
                          decoration: InputDecoration(
                        hintText: "Please enter amount in rupees",
                        hintStyle: TextStyle(
                            color: Color.fromARGB(255, 198, 128, 244)),
                        prefixIcon: Icon(Icons.monetization_on),
                        filled: true,
                        fillColor: Color.fromARGB(255, 158, 234, 173),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(50)),
                            borderSide: BorderSide(
                              color: Color.fromARGB(222, 219, 185, 254),
                              width: 2.0,
                              style: BorderStyle.solid,
                              strokeAlign: BorderSide.strokeAlignOutside,
                            )),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(50)),
                            borderSide: BorderSide(
                              color: Color.fromARGB(222, 58, 233, 227),
                              width: 2.0,
                              style: BorderStyle.solid,
                              strokeAlign: BorderSide.strokeAlignOutside,
                            )),
                      )),
                    ),
                    TextButton(
                        onPressed: () {
                          debugPrint('Presed');
                        },
                        child: const Text('pressed')),
                  ]
                  ),
            )
            )
            );
  }
}
